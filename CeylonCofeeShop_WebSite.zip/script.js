function showSpecial() {
    const special = "Today's special is a Pumpkin Spice Latte!";
    document.getElementById("special-text").innerText = special;
}
